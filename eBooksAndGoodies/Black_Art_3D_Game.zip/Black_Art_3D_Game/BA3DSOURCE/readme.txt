README.TXT for "The Black Art of 3D Game Programming" (C) Andre' LaMothe 1995

Within this directory you will find all the original sources for the Black Art of 3D Game Programming.
The code is 16-bit DOS based; however, I did port it to the Watcom 32-bit compiler running under the
DOS4G DOS Extender by Rational. The 32-bit versions of the libraries along with some samples are located
in the 32BITLIBS\ sub-directory.

Other than that, follow the book and enjoy!

Andre' LaMothe
ceo@nurve.net
