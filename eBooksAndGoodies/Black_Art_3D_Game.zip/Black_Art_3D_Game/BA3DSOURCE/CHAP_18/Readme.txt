
Kill or Be Killed User Instructions

Loading the Game

Kill or Be Killed is loaded with the single executable KRK.EXE, however,
to support music and sound FX the command line parameters 'm' and 's' must
be used such as:

KRK.EXE m s <ENTER>

Of course, if you want the music and sound to play, you must load in both
MIDPAK and DIGPAK with the files:

MIDPAK.COM
SOUNDRV.COM

which are generated with the menu driven programs SETM.EXE and SETD.EXE
in the sound chapter directory. I suggest that you possibly make a batch
file that looks something like this:

MIDPAK.COM
SOUNDRV.COM
KRK.EXE  m s

The only reason I didn't do this is I'm not sure if you want music and sound
all the time. Of course, a better way would be to allow the main menu in the
game to turn music and sound on/off. Maybe your version of the game should have
that? Whatever way you start the game up, the game will go through the
introduction sequence and drop you off in the main menu. Finally, KRK needs
about 580K of memory to run after the sound and music drivers have been loaded.


Playing the Game

When you get to the main menu, you really don't need to do anything, you can
simply select the Challenge menu item and start playing, but check out the
Select Mech and Rules menu items since I worked really hard on them! Once you
enter into the game grid the ship is controlled with the following keys:


<RIGHT ARROW>	- Turns the ship right.
<LEFT ARROW>    - Turns the ship left.
<UP ARROW>      - Increases throttle.
<DOWN ARROW>	- Decreases throttle.	

<T>             - Selects tactical multi function displays.
<H>             - Toggles heads up display.
<S>             - Toggles scanner.
<SPACE BAR>     - Fires missile.
<ESC>           - Exits back to main menu.

As far as goal of the game: simply hunt down and kill everything!

Problems with the Game

About the only trouble you might have with the game is not enough memory to
run it. If you do encounter sound, music, or lock up problems then unload all
TSRs and drivers to free up as much conventional memory ass possible. And
remember, if you want sound and music, you must load MIDPAK.COM and SOUNDRV.COM.



